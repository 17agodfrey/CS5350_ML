Just run hw1_p2_FINAL.py as in python3 hw1_p2_FINAL.py

I was having trouble getting the run.sh file to work on CADE machines 